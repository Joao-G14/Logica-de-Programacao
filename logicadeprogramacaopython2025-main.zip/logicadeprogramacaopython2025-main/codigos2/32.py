while input() != "2002":
    print("Senha Inválida")
    
print("Acesso Permitido")