J=9000000000
I=2

while J >= 0:
    print(f'I={I} J={J}')

    J=J-5
    I=I+3