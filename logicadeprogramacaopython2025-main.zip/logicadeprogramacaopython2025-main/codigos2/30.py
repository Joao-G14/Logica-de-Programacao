I=1
J=7

for contador1 in range(100000000):    
    for contador2 in range(3):
        print(f'I={I} J={J}')
        J=J-1
    
    I=I+2
    J=J+5