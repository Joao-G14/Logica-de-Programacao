valor = int(input())

for x in range(valor):
    print(f'{x+1} {(x+1)**2} {(x+1)**3}')