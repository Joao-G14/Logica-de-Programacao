r = float(input())
pi = 3.14159

volume = 4/3 * pi * r**3

print(f'VOLUME = {volume:.3f}')