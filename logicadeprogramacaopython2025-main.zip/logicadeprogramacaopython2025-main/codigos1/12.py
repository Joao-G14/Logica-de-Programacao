minutos = 2 * int(input())

print(f'{minutos} minutos')