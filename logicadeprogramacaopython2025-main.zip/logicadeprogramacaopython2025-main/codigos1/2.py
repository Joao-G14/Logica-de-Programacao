# inserção das entradas
a = int(input())
b = int(input())

print(f'x = {a + b}')