A = int(input())
B = int(input())

SOMA = A + B

print(f'SOMA = {SOMA}')