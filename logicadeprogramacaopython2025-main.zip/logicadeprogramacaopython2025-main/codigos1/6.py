A = int(input())
B = int(input())
C = int(input())
D = int(input())

print(f'DIFERENCA = {A * B - C * D}')