distancia = int(input())
combustivel = float(input())

print(f'{distancia/combustivel:.3f} km/l')
