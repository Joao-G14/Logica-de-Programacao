r = float(input())

area = 3.14159*(r**2)

print(f'A={area:.2f}')