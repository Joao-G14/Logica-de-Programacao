a = float(input())
b = float(input())

media = (3.5*a + 7.5*b) / 11

print(f'MEDIA = {media:.5f}')