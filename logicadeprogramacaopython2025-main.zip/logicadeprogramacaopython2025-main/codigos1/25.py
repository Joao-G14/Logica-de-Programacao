import calendar

mes = int(input())

print(calendar.month_name[mes])